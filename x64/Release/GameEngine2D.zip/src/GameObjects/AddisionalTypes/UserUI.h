#pragma once
class UserUI
{
public:
	virtual void drawInterface() {}
};

