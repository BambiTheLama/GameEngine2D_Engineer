#pragma once
class Interactive
{
public:
	virtual void interact() = 0;
};

