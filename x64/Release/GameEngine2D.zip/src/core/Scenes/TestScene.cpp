#include "TestScene.h"

TestScene::TestScene()
{

}

TestScene::~TestScene()
{

}

void TestScene::start()
{

}

void TestScene::update(float deltaTime)
{

}

void TestScene::draw()
{

}